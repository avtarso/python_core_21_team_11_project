# python_core_21_team_11_project
Command line bot personal assistant
