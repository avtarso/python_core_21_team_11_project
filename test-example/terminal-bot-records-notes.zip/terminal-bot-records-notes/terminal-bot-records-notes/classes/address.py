from classes.field import Field

class Address(Field):
    pass