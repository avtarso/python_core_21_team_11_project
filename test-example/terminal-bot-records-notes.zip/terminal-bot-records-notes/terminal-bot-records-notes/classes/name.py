from classes.field import Field

class Name(Field):
    pass