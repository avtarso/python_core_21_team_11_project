filename = "adressbook.pkl"
PAG = 4

notes_filename = "notes.pkl"